import java.sql.Connection;

import util.dbUtil;

public class ExecuteExample {
	public static void main(String str[]) {
		Connection con=null;
		con=dbUtil.getConnection();	
	}
}
