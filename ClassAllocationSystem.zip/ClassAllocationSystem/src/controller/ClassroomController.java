package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.ClassroomModel;
import util.dbUtil;

public class ClassroomController {
	private ClassroomModel classroomModel;
	private ClassroomController classroomController;
	private static ArrayList<Integer> classroom_number=new ArrayList<Integer>();
	
	public static ArrayList<Integer> populateList(){
		Connection con=null;
		Statement st;
		ResultSet rs=null;
		
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select classroom_number from classroom";//,schedule where classroom.classroom_number=schedule.classroom_number and schedule.classroom_occupied='No'";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				classroom_number.add(rs.getInt("classroom_number"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return classroom_number;
	}
}
