package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.TeacherModel;
import util.dbUtil;
import view.Login;
import view.TeacherScreen;

public class TeacherController {
	private TeacherModel teacherModel;
	private ArrayList<String> storeTeacherNames=new ArrayList<String>();
	
	public void setParent(TeacherModel teacherModel) {
		this.teacherModel=teacherModel;
	}
	
	@SuppressWarnings("deprecation")
	public void validateLogin() {
		Connection con = null;
		Statement st;
		ResultSet rs=null;
		String userID,password;
		
		userID=teacherModel.getTeacherUserId();
		password=teacherModel.getTeacherPassword();
		
		try {
			con=dbUtil.getConnection();
			st=con.createStatement();
			String sql="select first_name,last_name from teacher";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				if(userID.equals(rs.getString("first_name")) && password.equals(rs.getString("last_name"))){
					TeacherScreen teacherScreenObject=new TeacherScreen();
					teacherScreenObject.show();
					Login loginObject=new Login();
					loginObject.dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "Invalid User ID or Password", "Login", JOptionPane.ERROR_MESSAGE);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public ArrayList<String> populateList() {
		Connection con=null;
		Statement st;
		ResultSet rs=null;
		int subjectID;
		
		subjectID=SubjectController.fetchSubjectID();
		System.out.println(subjectID);
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select first_name,last_name from teacher,subject where teacher.subject_id=subject.subject_id and teacher.subject_id="+subjectID;
			rs=st.executeQuery(sql);
			while(rs.next()) {
				String name=rs.getString("first_name")+" "+rs.getString("last_name");
				storeTeacherNames.add(name);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return storeTeacherNames;
	}
	
	
}
