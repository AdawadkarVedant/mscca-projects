package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import model.StudentModel;
import util.dbUtil;
import view.Login;
import view.StudentScreen;

public class StudentController {
	private StudentModel studentModel;
	
	public void setParent(StudentModel studentModel) {
		this.studentModel=studentModel;
	}
	
	@SuppressWarnings("deprecation")
	public void validateLogin() {
		Connection con=null;
		ResultSet rs=null;
		Statement st;
		
		String userID,password;
		
		userID=studentModel.getStudentUserId();
		password=studentModel.getStudentPassword();
		
		try {
			con=dbUtil.getConnection();
			st=con.createStatement();
			String sql="select prn,first_name from student";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				if(userID.equals(rs.getString("prn")) && password.equals(rs.getString("first_name"))) {
					StudentScreen studentScreenObject=new StudentScreen();
					studentScreenObject.show();
					Login loginObject=new Login();
					loginObject.dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "Invalid User ID or Password", "Login", JOptionPane.ERROR_MESSAGE);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
