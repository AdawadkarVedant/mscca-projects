package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.swing.JOptionPane;
import javax.swing.plaf.OptionPaneUI;

import model.ScheduleModel;
import util.dbUtil;

public class ScheduleController {
	
	private ArrayList<Integer> storeClassrooms=new ArrayList<Integer>();
	private ArrayList<String> storeDates=new ArrayList<String>();
	private ArrayList<String> storeTime=new ArrayList<String>();
	private ScheduleModel scheduleModel;
	private ClassroomDecorator classroomDecorator;
	
	public void setParent(ScheduleModel scheduleModel) {
		this.scheduleModel=scheduleModel;
	}
	
	public void addSchedule() {
		Connection con=null;
		Statement st;
		ResultSet rs=null;
		String course_name=scheduleModel.getCourse_name();
		System.out.println("Course Name "+course_name);
		System.out.println(scheduleModel.getClassroom_number());
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			if(!ClassroomDecorator.getClassState()) {
				String sql="insert into schedule values(1,'"+scheduleModel.getCourse_name()+"','"+scheduleModel.getSubject_name()+"','"+scheduleModel.getTeacher_name()+"',"+scheduleModel.getClassroom_number()+",'"+scheduleModel.getDate_scheduled().toString()+"','"+scheduleModel.getTime_schedled()+"')";
				int x=st.executeUpdate(sql);
				if(x>0) {
					ClassroomDecorator.setClassState();
					JOptionPane.showMessageDialog(null, "Schedule Has Been Successfully Added", "Schedule", JOptionPane.INFORMATION_MESSAGE);
				}
				else {
					JOptionPane.showMessageDialog(null, "Schedule Cannot Be Currently Added", "Schedule", JOptionPane.ERROR_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Classroom Not Available", "Classroom Allocation", JOptionPane.ERROR_MESSAGE);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Integer> populateList() {
		Connection con=null;
		ResultSet rs=null;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select classroom_number from schedule";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				storeClassrooms.add(rs.getInt("classroom_number"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		Set<Integer> setList=new LinkedHashSet<Integer>(storeClassrooms);
		storeClassrooms.clear();
		storeClassrooms.addAll(setList);
		return storeClassrooms;
	}

	public ArrayList<String> populateDateList() {
		Connection con=null;
		ResultSet rs=null;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select date_scheduled from schedule where classroom_number="+scheduleModel.getClassroom_number();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
				String date_s=sdf.format(rs.getDate("date_scheduled"));
				//System.out.println(date_s);
				storeDates.add(date_s);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		Set<String> setList=new LinkedHashSet<String>(storeDates);
		storeDates.clear();
		storeDates.addAll(setList);
		return storeDates;
	}

	public ArrayList<String> populateTimeList() {
		Connection con=null;
		ResultSet rs=null;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select time_scheduled from schedule where date_scheduled='"+scheduleModel.getDate_scheduled()+"'";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				storeTime.add(rs.getString("time_scheduled"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return storeTime;
	}
}
