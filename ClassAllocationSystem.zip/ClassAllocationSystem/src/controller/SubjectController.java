package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.CourseModel;
import model.SubjectModel;
import util.dbUtil;

public class SubjectController {
	
	private static SubjectModel subjectModel;
	private CourseModel courseModel;
	private CourseController courseController;
	private ArrayList<String> storeSubjectNames=new ArrayList<String>();

	public void setParent(SubjectModel subjectModel) {
		this.subjectModel=subjectModel;
	}

	public ArrayList<String> populateList() {
		Connection con=null;
		Statement st;
		ResultSet rs=null;
		int courseID;
		
		//CourseModel courseModel=new CourseModel();
		courseID=CourseController.fetchCourseID();
		//System.out.println(courseID);
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select subject_name from subject,course where subject.course_id=course.course_id and subject.course_id="+courseID;
			rs=st.executeQuery(sql);
			while(rs.next()) {
				storeSubjectNames.add(rs.getString("subject_name"));
				//System.out.println(rs.getString("subject_name"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return storeSubjectNames;
	}
	
	public static int fetchSubjectID() {
		int subjectID = 0;
		String subjectName = subjectModel.getSubjectName();
		Connection con =null;
		ResultSet rs=null;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select subject_id from subject where subject_name='"+subjectName+"'";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				subjectID=rs.getInt("subject_id");
				//System.out.println(rs.getInt("subject_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return subjectID;
	}
}
