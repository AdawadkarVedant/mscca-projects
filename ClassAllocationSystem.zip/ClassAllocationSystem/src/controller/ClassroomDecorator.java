package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.ClassroomModel;
import model.ScheduleModel;
import util.dbUtil;

public class ClassroomDecorator{
	private static ScheduleModel scheduleModel;
	
	public void setState(ScheduleModel scheduleModel) {
		this.scheduleModel=scheduleModel;
	}
	
	public static boolean getClassState() {
		Connection con=null;
		Statement st;
		ResultSet rs=null;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select classroom_number,date_scheduled,time_scheduled from class_state where classroom_number="+scheduleModel.getClassroom_number()+" and date_scheduled='"+scheduleModel.getDate_scheduled()+"' and time_scheduled='"+scheduleModel.getTime_schedled()+"'";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public static void setClassState() {
		Connection con=null;
		ResultSet rs=null;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="insert into class_state values("+scheduleModel.getClassroom_number()+",'"+scheduleModel.getDate_scheduled()+"','"+scheduleModel.getTime_schedled()+"')";
			int x=st.executeUpdate(sql);
			if(x>0) {
				System.out.println("State Updated");
			}
			else {
				System.out.println("State Updation Failed");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void updateSchedule() {
		Connection con;
		ResultSet rs;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="update schedule set course_name='"+scheduleModel.getCourse_name()+"',subject_name='"+scheduleModel.getSubject_name()+"',teacher_name='"+scheduleModel.getTeacher_name()+"',date_scheduled='"+scheduleModel.getDate_scheduled()+"',time_scheduled='"+scheduleModel.getTime_schedled()+"',classroom_number="+scheduleModel.getClassroom_number()+" where classroom_number="+scheduleModel.getClassroom_number()+" and date_scheduled='"+scheduleModel.getDate_scheduled()+"' and time_scheduled='"+scheduleModel.getTime_schedled()+"'";
			int x=st.executeUpdate(sql);
			if(x>0) {
				JOptionPane.showMessageDialog(null, "Schedule Updated", "Schedule", JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				JOptionPane.showMessageDialog(null, "Schedule Cannot Be Updated", "Schedule", JOptionPane.ERROR_MESSAGE);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}