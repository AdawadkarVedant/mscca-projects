package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.CourseModel;
import util.dbUtil;

public class CourseController {
	
	private static CourseModel courseModel;
	private static ArrayList<String> storeCourseNames=new ArrayList<String>();
	
	public ArrayList<String> populateList() {
		Connection con=null;
		ResultSet rs=null;
		Statement st;
		
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select course_name from course";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				storeCourseNames.add(rs.getString("course_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return storeCourseNames;
	}
	
	public static int fetchCourseID() {
		int courseID = 0;
		String courseName=courseModel.getCourseName();
		Connection con =null;
		ResultSet rs=null;
		Statement st;
		con=dbUtil.getConnection();
		try {
			st=con.createStatement();
			String sql="select course_id from course where course_name='"+courseName+"'";
			rs=st.executeQuery(sql);
			while(rs.next()) {
				courseID=rs.getInt("course_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return courseID;
	}
	
	public void setParent(CourseModel courseModel) {
		this.courseModel=courseModel;
	}
}
