package model;

public class ScheduleModel {
	private String course_name;
	private String subject_name;
	private String teacher_name;
	private int classroom_number;
	private String date_scheduled;
	private String time_schedled;
	
	public ScheduleModel() {}
	
	public ScheduleModel(String course_name, String subject_name, String teacher_name, int classroom_number,
			String date_scheduled, String time_schedled) {
		super();
		this.course_name = course_name;
		this.subject_name = subject_name;
		this.teacher_name = teacher_name;
		this.classroom_number = classroom_number;
		this.date_scheduled = date_scheduled;
		this.time_schedled = time_schedled;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public String getSubject_name() {
		return subject_name;
	}

	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}

	public String getTeacher_name() {
		return teacher_name;
	}

	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}

	public int getClassroom_number() {
		return classroom_number;
	}

	public void setClassroom_number(int classroom_number) {
		this.classroom_number = classroom_number;
	}

	public String getDate_scheduled() {
		return date_scheduled;
	}

	public void setDate_scheduled(String date_scheduled) {
		this.date_scheduled = date_scheduled;
	}

	public String getTime_schedled() {
		return time_schedled;
	}

	public void setTime_schedled(String time_schedled) {
		this.time_schedled = time_schedled;
	}
}
