package model;

public class StudentModel {
	private String prn;
	private String firstName;
	private String lastName;
	private int courseID;
	private String division;
	
	public StudentModel() {}
	
	public StudentModel(String prn, String firstName, String lastName, int courseID, String division) {
		super();
		this.prn = prn;
		this.firstName = firstName;
		this.lastName = lastName;
		this.courseID = courseID;
		this.division = division;
	}
	
	public void setStudentUserId(String prn) {
		this.prn=prn;
	}
	
	public String getStudentUserId() {
		return prn;
	}
	
	public void setStudentPassword(String lastName) {
		this.lastName=lastName;
	}
	
	public String getStudentPassword() {
		return lastName;
	}

	public String getPrn() {
		return prn;
	}

	public void setPrn(String prn) {
		this.prn = prn;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}
}
