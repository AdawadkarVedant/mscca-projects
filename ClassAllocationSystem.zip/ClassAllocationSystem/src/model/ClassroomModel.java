package model;

import java.sql.Date;

public class ClassroomModel {

	private int classroomNumber;
	private boolean occupied;
	private int teacherID;
	private int subjectID;
	private int courseID;
	/*private String time_schedule;
	private java.util.Date date_schedule;*/
	
	public ClassroomModel(int classroomNumber, boolean occupied, int teacherID, int subjectID, int courseID) {
		super();
		this.classroomNumber = classroomNumber;
		this.occupied = occupied;
		this.teacherID = teacherID;
		this.subjectID = subjectID;
		this.courseID = courseID;
	}

	int getClassroomNumber() {
		return classroomNumber;
	}

	public void setClassroomNumber(int classroomNumber) {
		this.classroomNumber = classroomNumber;
	}

	public boolean isOccupied() {
		return occupied;
	}

	public void setOccupied(boolean occupied) {
		this.occupied = occupied;
	}

	public int getTeacherID() {
		return teacherID;
	}

	public void setTeacherID(int teacherID) {
		this.teacherID = teacherID;
	}

	public int getSubjectID() {
		return subjectID;
	}

	public void setSubjectID(int subjectID) {
		this.subjectID = subjectID;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}
}
