package model;

public class SubjectModel {
	private static int subjectID;
	private static String subjectName;
	private static int courseID;
	
	public SubjectModel() {}
	
	public SubjectModel(int subjectID, String subjectName, int courseID) {
		super();
		this.subjectID = subjectID;
		this.subjectName = subjectName;
		this.courseID = courseID;
	}

	public int getSubjectID() {
		return subjectID;
	}

	public void setSubjectID(int subjectID) {
		this.subjectID = subjectID;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}	
}
