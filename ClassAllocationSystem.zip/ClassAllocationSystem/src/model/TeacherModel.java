package model;

public class TeacherModel {
	private int teacherID;
	private String firstName;
	private String lastName;
	private String specialization;
	private int subjectID;
	
	public TeacherModel() {}
	
	public TeacherModel(int teacherID, String firstName, String lastName, String specialization, int subjectID) {
		super();
		this.teacherID = teacherID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.specialization = specialization;
		this.subjectID = subjectID;
	}

	public int getTeacherID() {
		return teacherID;
	}
	
	public void setTeacherUserId(String firstName) {
		this.firstName=firstName;
	}
	
	public String getTeacherUserId() {
		return firstName;
	}
	
	public void setTeacherPassword(String lastName) {
		this.lastName=lastName;
	}
	
	public String getTeacherPassword() {
		return lastName;
	}
	
	public void setTeacherID(int teacherID) {
		this.teacherID = teacherID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public int getSubjectID() {
		return subjectID;
	}

	public void setSubjectID(int subjectID) {
		this.subjectID = subjectID;
	}
}
