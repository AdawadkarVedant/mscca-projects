package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbUtil {
	public static Connection getConnection() {
		String driver="oracle.jdbc.driver.OracleDriver";
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection con=null;
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		String username="hr";
		String password="wayne";
		try {
			con=DriverManager.getConnection(url, username, password);
			if(con!=null) {
				//System.out.println("Connected");
			}
			else {
				System.out.println("Not Connected");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
