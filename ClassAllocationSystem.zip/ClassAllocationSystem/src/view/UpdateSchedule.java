package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;

import controller.ClassroomDecorator;
import controller.CourseController;
import controller.ScheduleController;
import controller.SubjectController;
import controller.TeacherController;
import model.CourseModel;
import model.ScheduleModel;
import model.SubjectModel;
import model.TeacherModel;

import javax.swing.JButton;

public class UpdateSchedule extends JFrame {
	
	private ScheduleController scheduleController;
	private ScheduleModel scheduleModel;
	private CourseController courseController;
	private CourseModel courseModel;
	private SubjectController subjectController;
	private SubjectModel subjectModel;
	private TeacherController teacherController;
	private TeacherModel teacherModel;
	private ClassroomDecorator classroomDecorator;
	
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateSchedule frame = new UpdateSchedule();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UpdateSchedule() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 568, 377);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUpdateSchedule = new JLabel("UPDATE SCHEDULE");
		lblUpdateSchedule.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblUpdateSchedule.setBounds(191, 11, 162, 19);
		contentPane.add(lblUpdateSchedule);
		
		JComboBox classroomBox = new JComboBox();
		classroomBox.setModel(new DefaultComboBoxModel(new String[] {"Select Classroom"}));
		classroomBox.setBounds(270, 44, 111, 20);
		contentPane.add(classroomBox);
		
		JLabel lblNewLabel = new JLabel("Select Classroom");
		lblNewLabel.setBounds(157, 47, 103, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblSelectDate = new JLabel("Select Date");
		lblSelectDate.setBounds(77, 89, 70, 14);
		contentPane.add(lblSelectDate);
		
		JComboBox timeBox = new JComboBox();
		timeBox.setModel(new DefaultComboBoxModel(new String[] {"Select Time"}));
		timeBox.setBounds(391, 86, 111, 20);
		contentPane.add(timeBox);
		
		JLabel lblSelectTime = new JLabel("Select Time");
		lblSelectTime.setBounds(325, 89, 54, 14);
		contentPane.add(lblSelectTime);
		
		JComboBox dateBox = new JComboBox();
		dateBox.setModel(new DefaultComboBoxModel(new String[] {"Select Date"}));
		dateBox.setBounds(157, 86, 111, 20);
		contentPane.add(dateBox);
		
		JLabel lblSelectCourse = new JLabel("Select Course");
		lblSelectCourse.setBounds(77, 132, 70, 14);
		contentPane.add(lblSelectCourse);
		
		JComboBox courseBox = new JComboBox();
		courseBox.setModel(new DefaultComboBoxModel(new String[] {"Select Course"}));
		courseBox.setBounds(157, 129, 111, 20);
		contentPane.add(courseBox);
		
		JLabel lblSelectSubject = new JLabel("Select Subject");
		lblSelectSubject.setBounds(311, 132, 70, 14);
		contentPane.add(lblSelectSubject);
		
		JComboBox subjectBox = new JComboBox();
		subjectBox.setModel(new DefaultComboBoxModel(new String[] {"Select Subject"}));
		subjectBox.setBounds(391, 129, 111, 20);
		contentPane.add(subjectBox);
		
		JLabel lblSelectTeacher = new JLabel("Select Teacher");
		lblSelectTeacher.setBounds(208, 186, 77, 14);
		contentPane.add(lblSelectTeacher);
		
		JComboBox teacherBox = new JComboBox();
		teacherBox.setModel(new DefaultComboBoxModel(new String[] {"Select Teacher"}));
		teacherBox.setBounds(295, 183, 111, 20);
		contentPane.add(teacherBox);
		
		JButton btnUpdateSchedule = new JButton("UPDATE SCHEDULE");
		btnUpdateSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String courseName_s=courseBox.getSelectedItem().toString();
			String subjectName_s=subjectBox.getSelectedItem().toString();
			String teacherName_s=teacherBox.getSelectedItem().toString();
			int classroom_s=Integer.parseInt(classroomBox.getSelectedItem().toString());
			String dateScheduled_s=dateBox.getSelectedItem().toString();
			String timeScheduled_s=timeBox.getSelectedItem().toString();

			scheduleModel=new ScheduleModel();
			scheduleController=new ScheduleController();
			classroomDecorator=new ClassroomDecorator();
			scheduleModel.setCourse_name(courseName_s);
			scheduleModel.setSubject_name(subjectName_s);
			scheduleModel.setTeacher_name(teacherName_s);
			scheduleModel.setClassroom_number(classroom_s);
			scheduleModel.setDate_scheduled(dateScheduled_s);
			scheduleModel.setTime_schedled(timeScheduled_s);
			classroomDecorator.setState(scheduleModel);
			classroomDecorator.updateSchedule();
			}
		});
		btnUpdateSchedule.setBounds(228, 242, 125, 23);
		contentPane.add(btnUpdateSchedule);
		
		scheduleController=new ScheduleController();
		ArrayList<Integer> alist=scheduleController.populateList();
		for(int n:alist) {
			classroomBox.addItem(n);
		}
		
		classroomBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				classroomBox.removeAll();
				int getSelectedClassroom=Integer.parseInt(classroomBox.getSelectedItem().toString());
				scheduleModel=new ScheduleModel();
				scheduleModel.setClassroom_number(getSelectedClassroom);
				scheduleController.setParent(scheduleModel);
				ArrayList<String>dateList=scheduleController.populateDateList();
				for(String date:dateList) {
					dateBox.addItem(date);
				}
			}
		});
		
		dateBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dateBox.removeAll();
				String getSelectedDate=dateBox.getSelectedItem().toString();
				scheduleModel=new ScheduleModel();
				scheduleModel.setDate_scheduled(getSelectedDate);
				scheduleController.setParent(scheduleModel);
				ArrayList<String>timeList=scheduleController.populateTimeList();
				for(String time:timeList) {
					timeBox.addItem(time);
				}
			}
		});
		
		courseController=new CourseController();
		ArrayList<String> courselist = courseController.populateList();
		
		for (String value : courselist) {
			courseBox.addItem(value);
			
		}
		
		courseBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				courseBox.removeAll();
				String item = (String) courseBox.getSelectedItem();
				//System.out.println(item);
				courseModel=new CourseModel();
				courseModel.setCourseName(item);
				courseController=new CourseController();
				courseController.setParent(courseModel);
				//courseController.fetchCourseID();
				subjectController=new SubjectController();
				ArrayList<String> subjectList=subjectController.populateList();
				for(String value:subjectList) {
					subjectBox.addItem(value);
				}
			}
		});
		
		
		subjectBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				subjectBox.removeAll();
				String item = (String) subjectBox.getSelectedItem();
				//System.out.println(item);
				subjectModel=new SubjectModel();
				subjectModel.setSubjectName(item);
				subjectController=new SubjectController();
				subjectController.setParent(subjectModel);
				teacherController=new TeacherController();
				ArrayList<String> teacherList=teacherController.populateList();
				for(String value:teacherList) {
					teacherBox.addItem(value);
				}
			}
		});
	}
}
