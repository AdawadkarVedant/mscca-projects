                                                                                                                                                                                 package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JMonthChooser;

import controller.ClassroomController;
import controller.ClassroomDecorator;
import controller.CourseController;
import controller.ScheduleController;
import controller.SubjectController;
import controller.TeacherController;
import model.CourseModel;
import model.ScheduleModel;
import model.SubjectModel;

import com.toedter.calendar.JDateChooser;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JLabel;
import java.awt.Font;

public class MainScreen extends JFrame {
	

	private JPanel contentPane;
	private JTextField setTime;
	private TeacherController teacherController;
	private CourseController courseController;
	private SubjectController subjectController;
	private CourseModel courseModel;
	private SubjectModel subjectModel;
	private ScheduleModel scheduleModel;
	private ScheduleController scheduleController;
	private ClassroomDecorator classroomDecorator;
	private String courseName_s;
	private String subjectName_s;
	private String teacherName_s;
	private int classroom_s;
	private String dateScheduled_s;
	private String timeScheduled_s;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainScreen frame = new MainScreen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainScreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 564, 305);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox courseDropDown = new JComboBox();
		courseDropDown.setModel(new DefaultComboBoxModel(new String[] {"Select Courses"}));
		courseDropDown.setBounds(154, 56, 139, 20);
		contentPane.add(courseDropDown);
		
		JComboBox subjectDropDown = new JComboBox();
		subjectDropDown.setModel(new DefaultComboBoxModel(new String[] {"Select Subject"}));
		subjectDropDown.setBounds(409, 56, 129, 20);
		contentPane.add(subjectDropDown);
		
		JComboBox tacherDropDown = new JComboBox();
		tacherDropDown.setModel(new DefaultComboBoxModel(new String[] {"Select Teacher"}));
		tacherDropDown.setBounds(409, 104, 129, 20);
		contentPane.add(tacherDropDown);
		
		JComboBox classroomDropDown = new JComboBox();
		classroomDropDown.setModel(new DefaultComboBoxModel(new String[] {"Select Classroom"}));
		classroomDropDown.setBounds(154, 104, 139, 20);
		contentPane.add(classroomDropDown);
		
		JDateChooser dateSelect = new JDateChooser();
		dateSelect.setBounds(154, 157, 139, 20);
		contentPane.add(dateSelect);
		
		setTime = new JTextField();
		setTime.setToolTipText("Time Should be in 24 Hours Format. Ex: 08:30-9.30");
		setTime.setBounds(409, 157, 129, 20);
		contentPane.add(setTime);
		setTime.setColumns(10);
		
		courseController=new CourseController();
		ArrayList<String> alist = courseController.populateList();
		
		for (String value : alist) {
			courseDropDown.addItem(value);
			
		}
		
		tacherDropDown.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				tacherDropDown.removeAll();
			}
		});
		
		classroomDropDown.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				classroomDropDown.removeAll();
			}
		});
		
		courseDropDown.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				courseDropDown.removeAll();
				String item = (String) courseDropDown.getSelectedItem();
				//System.out.println(item);
				courseModel=new CourseModel();
				courseModel.setCourseName(item);
				courseController=new CourseController();
				courseController.setParent(courseModel);
				//courseController.fetchCourseID();
				subjectController=new SubjectController();
				ArrayList<String> subjectList=subjectController.populateList();
				for(String value:subjectList) {
					subjectDropDown.addItem(value);
				}
			}
		});
		
		
		subjectDropDown.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				subjectDropDown.removeAll();
				String item = (String) subjectDropDown.getSelectedItem();
				//System.out.println(item);
				subjectModel=new SubjectModel();
				subjectModel.setSubjectName(item);
				subjectController=new SubjectController();
				subjectController.setParent(subjectModel);
				teacherController=new TeacherController();
				ArrayList<String> teacherList=teacherController.populateList();
				for(String value:teacherList) {
					tacherDropDown.addItem(value);
				}
				tacherDropDown.removeAll();
			}
		});
		
		ArrayList<Integer> classroomList=ClassroomController.populateList();
		for(int value:classroomList) {
			classroomDropDown.addItem(value);
		}
		
		JButton btnAddToSchedule = new JButton("ADD SCHEDULE");
		btnAddToSchedule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				courseName_s=courseDropDown.getSelectedItem().toString();
				subjectName_s=subjectDropDown.getSelectedItem().toString();
				teacherName_s=tacherDropDown.getSelectedItem().toString();
				classroom_s=Integer.parseInt(classroomDropDown.getSelectedItem().toString());
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
				dateScheduled_s=sdf.format(dateSelect.getDate());
				timeScheduled_s=setTime.getText().toString();

				scheduleModel=new ScheduleModel();
				scheduleController=new ScheduleController();
				classroomDecorator=new ClassroomDecorator();
				scheduleModel.setCourse_name(courseName_s);
				scheduleModel.setSubject_name(subjectName_s);
				scheduleModel.setTeacher_name(teacherName_s);
				scheduleModel.setClassroom_number(classroom_s);
				scheduleModel.setDate_scheduled(dateScheduled_s);
				scheduleModel.setTime_schedled(timeScheduled_s);
				scheduleController.setParent(scheduleModel);
				classroomDecorator.setState(scheduleModel);
				scheduleController.addSchedule();
			}
		});
		btnAddToSchedule.setBounds(221, 202, 137, 23);
		contentPane.add(btnAddToSchedule);
		
		JLabel lblAddSchedule = new JLabel("ADD SCHEDULE");
		lblAddSchedule.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblAddSchedule.setBounds(207, 11, 137, 20);
		contentPane.add(lblAddSchedule);
		
		JLabel lblSelectCourse = new JLabel("Select Subject");
		lblSelectCourse.setBounds(303, 58, 96, 17);
		contentPane.add(lblSelectCourse);
		
		JLabel label = new JLabel("Select Course");
		label.setBounds(41, 58, 103, 17);
		contentPane.add(label);
		
		JLabel lblSelectClassroom = new JLabel("Select Date");
		lblSelectClassroom.setBounds(41, 160, 103, 17);
		contentPane.add(lblSelectClassroom);
		
		JLabel lblSelectTeacher = new JLabel("Select Teacher");
		lblSelectTeacher.setBounds(303, 106, 96, 17);
		contentPane.add(lblSelectTeacher);
		
		JLabel label_1 = new JLabel("Select Classroom");
		label_1.setBounds(41, 106, 103, 17);
		contentPane.add(label_1);
		
		JLabel lblSetTime = new JLabel("Set Time");
		lblSetTime.setBounds(328, 160, 71, 17);
		contentPane.add(lblSetTime);
	}
}
