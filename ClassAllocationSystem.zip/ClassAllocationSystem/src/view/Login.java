package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.StudentController;
import controller.TeacherController;
import model.StudentModel;
import model.TeacherModel;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField userName;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 449, 302);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterUserId = new JLabel("Enter User ID");
		lblEnterUserId.setBounds(56, 57, 79, 14);
		contentPane.add(lblEnterUserId);
		
		JLabel lblEnterPassword = new JLabel("Enter Password");
		lblEnterPassword.setBounds(56, 88, 107, 14);
		contentPane.add(lblEnterPassword);
		
		userName = new JTextField();
		userName.setToolTipText("Enter User ID");
		userName.setBounds(173, 54, 167, 20);
		contentPane.add(userName);
		userName.setColumns(10);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerListModel(new String[] {"Admin", "Teacher", "Student"}));
		spinner.setBounds(183, 116, 157, 20);
		contentPane.add(spinner);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				String getSelected,userID,password;
				getSelected=spinner.getValue().toString();
				userID=userName.getText().toString();
				password=Login.this.password.getText().toString();
				switch(getSelected) {
				case "Admin":
					if(userID.equals("Admin") && password.equals("Password")) {
						String[] options= {"Add Schedule","Update Schedule"};
						int response=JOptionPane.showOptionDialog(null, "Welcome Admin, Select An Option", "Class Allocation", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
						switch(response) {
						case JOptionPane.YES_OPTION:	
							MainScreen mainScreenObject=new MainScreen();
							mainScreenObject.show();
							Login.this.dispose();
							break;
						case JOptionPane.NO_OPTION:
							UpdateSchedule updateSchedule=new UpdateSchedule();
							updateSchedule.show();
							Login.this.dispose();
							break;
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "Wrong User ID or Password", "Login Error", JOptionPane.OK_OPTION);
						userName.setText("");
						Login.this.password.setText("");
					}
					break;
				case "Teacher":
					TeacherModel teacherModel=new TeacherModel();
					teacherModel.setTeacherUserId(userID);				
					teacherModel.setTeacherPassword(password);
					TeacherController teacherController=new TeacherController();
					teacherController.setParent(teacherModel);
					teacherController.validateLogin();
					Login.this.dispose();
					break;
				case "Student":
					StudentModel studentModel=new StudentModel();
					studentModel.setStudentUserId(userID);
					studentModel.setStudentPassword(password);
					StudentController studentController=new StudentController();
					studentController.setParent(studentModel);
					studentController.validateLogin();
					Login.this.dispose();
				}
			}
		});
		btnLogin.setBounds(161, 158, 89, 23);
		contentPane.add(btnLogin);
		
		JLabel lblLogin = new JLabel("LOGIN");
		lblLogin.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblLogin.setBounds(173, 11, 52, 14);
		contentPane.add(lblLogin);
		
		JLabel lblNewLabel = new JLabel("Select User Type");
		lblNewLabel.setBounds(56, 118, 107, 17);
		contentPane.add(lblNewLabel);
		
		password = new JPasswordField();
		password.setBounds(173, 85, 167, 20);
		contentPane.add(password);
	}
}
